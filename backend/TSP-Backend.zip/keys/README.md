# Place your Firebase Admin service account JSON here.
# Download from: Firebase Console → Project Settings → Service accounts → Generate new private key
# Filename: firebase-service-account.json
