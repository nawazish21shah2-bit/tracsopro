import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Modal,
  TextInput,
  FlatList,
  TouchableOpacity,
  ActivityIndicator,
} from 'react-native';
import { X, Search } from 'react-native-feather';
import ProfileAvatar from '../common/ProfileAvatar';
import { parseDisplayName } from '../../utils/parseDisplayName';
import { pickProfilePictureUrl } from '../../utils/profilePictureUtils';
import { COLORS, TYPOGRAPHY, SPACING, BORDER_RADIUS, SHADOWS } from '../../styles/globalStyles';
import apiService from '../../services/api';
import { useSelector } from 'react-redux';
import { RootState } from '../../store';

interface UserOption {
  id: string;
  userId: string;
  name: string;
  role: 'ADMIN' | 'GUARD' | 'CLIENT';
  avatar?: string;
}

interface NewChatModalProps {
  visible: boolean;
  onClose: () => void;
  onSelectUser: (userId: string, userName: string, userRole: string) => void;
  currentUserRole?: string;
}

const NewChatModal: React.FC<NewChatModalProps> = ({
  visible,
  onClose,
  onSelectUser,
  currentUserRole,
}) => {
  const { user } = useSelector((state: RootState) => state.auth);
  const [searchQuery, setSearchQuery] = useState('');
  const [users, setUsers] = useState<UserOption[]>([]);
  const [loading, setLoading] = useState(false);
  const [filteredUsers, setFilteredUsers] = useState<UserOption[]>([]);

  useEffect(() => {
    if (visible) {
      loadAvailableUsers();
    } else {
      setSearchQuery('');
      setUsers([]);
    }
  }, [visible]);

  useEffect(() => {
    if (searchQuery.trim()) {
      const filtered = users.filter(
        (u) =>
          u.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          u.role.toLowerCase().includes(searchQuery.toLowerCase())
      );
      setFilteredUsers(filtered);
    } else {
      setFilteredUsers(users);
    }
  }, [searchQuery, users]);

  const loadAvailableUsers = async () => {
    try {
      setLoading(true);

      // Get available users based on current user's role
      const availableUsers: UserOption[] = [];

      if (currentUserRole === 'ADMIN' || currentUserRole === 'SUPER_ADMIN') {
        // Admins can chat with guards and clients
        const [guardsResponse, clientsResponse] = await Promise.all([
          apiService.getGuards(1, 100),
          apiService.getClients(1, 100),
        ]);

        if (guardsResponse.success && guardsResponse.data) {
          const guards = (guardsResponse.data as any).items || [];
          guards.forEach((guard: any) => {
            if (guard.user && guard.user.id !== user?.id) {
              const guardName = `${guard.user.firstName || ''} ${guard.user.lastName || ''}`.trim();
              availableUsers.push({
                id: guard.id,
                userId: guard.user.id,
                name: guardName || guard.user.email || `Guard ${guard.id}`,
                role: 'GUARD',
                avatar: guard.profilePictureUrl || guard.user.avatar,
              });
            }
          });
        }

        if (clientsResponse.success && clientsResponse.data) {
          const clients = (clientsResponse.data as any).items || [];
          clients.forEach((client: any) => {
            if (client.user && client.user.id !== user?.id) {
              const clientName = `${client.user.firstName || ''} ${client.user.lastName || ''}`.trim();
              availableUsers.push({
                id: client.id,
                userId: client.user.id,
                name: clientName || client.user.email || `Client ${client.id}`,
                role: 'CLIENT',
                avatar: pickProfilePictureUrl(client.user),
              });
            }
          });
        }
      } else if (currentUserRole === 'CLIENT') {
        // Clients can chat with guards assigned to their sites
        const guardsResponse = await apiService.getClientGuards(1, 100);
        if (guardsResponse.success && guardsResponse.data) {
          const guards = guardsResponse.data.items || guardsResponse.data || [];
          guards.forEach((guard: any) => {
            const guardUser = guard.user || guard;
            if (guardUser && guardUser.id !== user?.id) {
              availableUsers.push({
                id: guard.id || guardUser.id,
                userId: guardUser.id,
                name: `${guardUser.firstName || ''} ${guardUser.lastName || ''}`.trim() || guardUser.email || 'Guard',
                role: 'GUARD',
                avatar: pickProfilePictureUrl(guard),
              });
            }
          });
        }

        // Also add existing admins from chats
        const chatsResponse = await apiService.getChatRooms();
        if (chatsResponse.success && chatsResponse.data) {
          const chats = chatsResponse.data as any[];
          chats.forEach((chat: any) => {
            if (chat.participants) {
              chat.participants.forEach((participant: any) => {
                const pUser = participant.user || participant;
                if (
                  pUser.id !== user?.id &&
                  (pUser.role === 'ADMIN' || pUser.role === 'SUPER_ADMIN') &&
                  !availableUsers.find((u) => u.userId === pUser.id)
                ) {
                  availableUsers.push({
                    id: pUser.id,
                    userId: pUser.id,
                    name: `${pUser.firstName || ''} ${pUser.lastName || ''}`.trim() || pUser.email || 'Admin',
                    role: 'ADMIN',
                    avatar: pickProfilePictureUrl(pUser),
                  });
                }
              });
            }
          });
        }
      } else if (currentUserRole === 'GUARD') {
        // Guards can see admins and clients from their chats
        const chatsResponse = await apiService.getChatRooms();
        if (chatsResponse.success && chatsResponse.data) {
          const chats = chatsResponse.data as any[];
          chats.forEach((chat: any) => {
            if (chat.participants) {
              chat.participants.forEach((participant: any) => {
                const pUser = participant.user || participant;
                if (
                  pUser.id !== user?.id &&
                  (pUser.role === 'ADMIN' || pUser.role === 'SUPER_ADMIN' || pUser.role === 'CLIENT') &&
                  !availableUsers.find((u) => u.userId === pUser.id)
                ) {
                  availableUsers.push({
                    id: pUser.id,
                    userId: pUser.id,
                    name: `${pUser.firstName || ''} ${pUser.lastName || ''}`.trim() || pUser.email || pUser.role,
                    role: pUser.role === 'CLIENT' ? 'CLIENT' : 'ADMIN',
                    avatar: pickProfilePictureUrl(pUser),
                  });
                }
              });
            }
          });
        }
      }

      setUsers(availableUsers);
      setFilteredUsers(availableUsers);
    } catch (error) {
      console.error('Error loading available users:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSelectUser = (selectedUser: UserOption) => {
    onSelectUser(selectedUser.userId, selectedUser.name, selectedUser.role);
    onClose();
  };

  const renderUserItem = ({ item }: { item: UserOption }) => (
    <TouchableOpacity
      style={styles.userItem}
      onPress={() => handleSelectUser(item)}
      activeOpacity={0.7}
    >
      <View style={styles.avatarContainer}>
        <ProfileAvatar
          {...parseDisplayName(item.name)}
          profilePictureUrl={item.avatar}
          size={48}
        />
      </View>
      <View style={styles.userInfo}>
        <Text style={styles.userName}>{item.name}</Text>
        <Text style={styles.userRole}>{item.role}</Text>
      </View>
    </TouchableOpacity>
  );

  return (
    <Modal
      visible={visible}
      animationType="slide"
      transparent={true}
      onRequestClose={onClose}
    >
      <View style={styles.modalOverlay}>
        <View style={styles.modalContent}>
          {/* Header */}
          <View style={styles.header}>
            <Text style={styles.headerTitle}>New Chat</Text>
            <TouchableOpacity onPress={onClose} style={styles.closeButton}>
              <X width={24} height={24} color={COLORS.textPrimary} />
            </TouchableOpacity>
          </View>

          {/* Search Bar */}
          <View style={styles.searchContainer}>
            <View style={styles.searchInputContainer}>
              <Search width={20} height={20} color={COLORS.textTertiary} style={styles.searchIcon} />
              <TextInput
                style={styles.searchInput}
                placeholder="Search users..."
                value={searchQuery}
                onChangeText={setSearchQuery}
                placeholderTextColor={COLORS.textTertiary}
              />
            </View>
          </View>

          {/* User List */}
          {loading ? (
            <View style={styles.loadingContainer}>
              <ActivityIndicator size="large" color={COLORS.primary} />
              <Text style={styles.loadingText}>Loading users...</Text>
            </View>
          ) : (
            <FlatList
              data={filteredUsers}
              renderItem={renderUserItem}
              keyExtractor={(item) => item.userId}
              style={styles.userList}
              ListEmptyComponent={
                <View style={styles.emptyContainer}>
                  <Text style={styles.emptyText}>No users found</Text>
                  <Text style={styles.emptySubtext}>
                    {searchQuery
                      ? 'Try a different search term'
                      : 'No available users to chat with'}
                  </Text>
                </View>
              }
            />
          )}
        </View>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: COLORS.backgroundPrimary,
    borderTopLeftRadius: BORDER_RADIUS.xl,
    borderTopRightRadius: BORDER_RADIUS.xl,
    maxHeight: '90%',
    paddingBottom: SPACING.lg,
    minHeight: 400,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: SPACING.lg,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.borderCard,
  },
  headerTitle: {
    fontSize: TYPOGRAPHY.fontSize.xl,
    fontWeight: TYPOGRAPHY.fontWeight.semibold,
    color: COLORS.textPrimary,
  },
  closeButton: {
    padding: SPACING.xs,
  },
  searchContainer: {
    padding: SPACING.lg,
  },
  searchInputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.backgroundSecondary,
    borderRadius: BORDER_RADIUS.md,
    paddingHorizontal: SPACING.md,
    borderWidth: 1,
    borderColor: COLORS.borderLight,
    height: 48,
  },
  searchIcon: {
    marginRight: SPACING.sm,
  },
  searchInput: {
    flex: 1,
    fontSize: TYPOGRAPHY.fontSize.md,
    color: COLORS.textPrimary,
    height: '100%',
  },
  userList: {
    flex: 1,
  },
  userItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: SPACING.lg,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.backgroundSecondary,
  },
  avatarContainer: {
    marginRight: SPACING.md,
  },
  avatar: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: COLORS.backgroundSecondary,
  },
  avatarPlaceholder: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: COLORS.backgroundSecondary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  userInfo: {
    flex: 1,
  },
  userName: {
    fontSize: TYPOGRAPHY.fontSize.md,
    fontWeight: TYPOGRAPHY.fontWeight.semibold,
    color: COLORS.textPrimary,
    marginBottom: 2,
  },
  userRole: {
    fontSize: TYPOGRAPHY.fontSize.xs,
    color: COLORS.textSecondary,
    textTransform: 'capitalize',
  },
  loadingContainer: {
    padding: SPACING.xxxxl,
    alignItems: 'center',
  },
  loadingText: {
    fontSize: TYPOGRAPHY.fontSize.md,
    color: COLORS.textSecondary,
    marginTop: SPACING.md,
  },
  emptyContainer: {
    padding: SPACING.xxxxl,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: TYPOGRAPHY.fontSize.lg,
    fontWeight: TYPOGRAPHY.fontWeight.semibold,
    color: COLORS.textPrimary,
    marginBottom: SPACING.sm,
  },
  emptySubtext: {
    fontSize: TYPOGRAPHY.fontSize.sm,
    color: COLORS.textSecondary,
    textAlign: 'center',
  },
});

export default NewChatModal;

